import 'package:flutter/material.dart';
import 'package:mobile/api_service.dart';
import 'package:mobile/lagu_model.dart';
import 'package:mobile/lagu_response.dart';

class LaguListScreen extends StatefulWidget {
  @override
  _LaguListScreenState createState() => _LaguListScreenState();
}

class _LaguListScreenState extends State<LaguListScreen> {
  final ApiService apiService = ApiService(baseUrl: 'http://localhost/tpmobile');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lagu List'),
      ),
      body: FutureBuilder<ProductResponse?>(
        future: apiService.getProducts(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.listLagu.isEmpty) {
            return Center(child: Text('No data available'));
          } else {
            List<LaguModel> listLagu = snapshot.data!.listLagu;
            return ListView.builder(
              itemCount: listLagu.length,
              itemBuilder: (context, index) {
                LaguModel lagu = listLagu[index];
                return ListTile(
                  title: Text(lagu.judulLagu ?? ''),
                  subtitle: Text(lagu.artis ?? ''),
                  // Add other fields as needed
                );
              },
            );
          }
        },
      ),
    );
  }
}
