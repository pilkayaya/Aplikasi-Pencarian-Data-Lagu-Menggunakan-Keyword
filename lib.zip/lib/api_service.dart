import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
//import 'package:mobile/lagu_model.dart';
import 'package:mobile/lagu_response.dart';

class ApiService {
  final String baseUrl;

  ApiService({required this.baseUrl});

  Future<ProductResponse?> getProducts() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/data.php'));
      debugPrint('GET Product : ${response.body}');

      if (response.statusCode == 200) {
        // If the server returns a 200 OK response, parse the JSON data
        return ProductResponse.fromJson(jsonDecode(response.body)['data']);
      } else {
        // If the server did not return a 200 OK response, throw an exception.
        throw Exception('Failed to load products');
      }
    } catch (e) {
      debugPrint(e.toString());
      return null;
    }
  }
}
